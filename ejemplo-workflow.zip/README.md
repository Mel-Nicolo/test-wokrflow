# assertJTest
Test AssertJ with GitHub actions
